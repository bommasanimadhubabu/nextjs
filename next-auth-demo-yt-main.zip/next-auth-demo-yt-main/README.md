This is a Next.js Auth project made for educational purpose
Part one: [See Video](https://youtu.be/EFucgPdjeNg).
Part two: [See Video](https://youtu.be/ollnut-J47s).

Just do `npm install`
