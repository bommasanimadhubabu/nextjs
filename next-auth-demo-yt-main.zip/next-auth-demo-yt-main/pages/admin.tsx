import { FC } from "react";

interface Props {}

const Admin: FC<Props> = (props): JSX.Element => {
  return <div>admin</div>;
};

export default Admin;
